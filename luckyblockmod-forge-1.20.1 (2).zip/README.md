# Lucky Block Ascension — Forge 1.20.1

## Build

Requires JDK 17 and Gradle 8.8. Run `gradle --no-daemon clean build`; the mod JAR is written to `build/libs/`.
GitHub Actions is configured in `.github/workflows/build.yml` and uploads the compiled JAR as an artifact. If your repo contains only a source ZIP, the workflow extracts the archive automatically.

## Passive ability

Keeping the Lucky Block anywhere in your main inventory or offhand grants passive flight access in Survival/Adventure and sets flight speed to 0.10 (twice vanilla creative flight speed, 0.05). Double-tap jump to start/stop flying. Removing the Lucky Block restores the player's previous flight settings. The passive does not consume an active ability slot or cooldown.

## Install and controls

Install on Minecraft 1.20.1 with Forge 47.x. Put the built JAR in `mods/`.

- `/give @s luckyblockmod:lucky_block`
- Press **G** to open the compact, paginated ability picker (10 powers per page).
- Right-click casts the selected power; selection defaults to a random power.
- Sneak + right-click casts Omega Beam.

## This refinement

- Kept all 34 abilities, but separated powers that felt too similar. Overdrive is now a short offensive rush; Lucky Ascension remains the long, broad buff. Thunder God chains lightning between aimed targets while Lightning Storm calls random strikes around you. Chrono Burst marks a target area for delayed damage, while Time Stop halts nearby hostile mobs. Reality Break shuffles enemy positions rather than repeating Void Rift's damage/debuff effect.
- Item Wish opens a searchable item catalogue by display name or registry ID. Item Rain remains a random rain of item entities.
- Reduced overlapping particle spam. Each dimension is capped at 160 effect calls / 350 particles per tick; bursts max at 24 particles and rings at 14 points. Screen flash/shake packets are limited per player, and client-side flash/shake intensity is capped. Long meteor trails and the hurricane use fewer repeating effects.
- The ability menu stays paginated, while the Item Wish screen shows readable item names and their registry IDs on hover.

This ZIP contains source code and the build workflow, not a precompiled JAR. A successful GitHub Actions build is still needed to verify compilation in the Forge toolchain.


## Tesseract / VFX overhaul

- **Giant Tesseract** now renders a true projected 4D hypercube: 16 vertices and 32 edges, with two distinct cube frames and the eight W-axis connector edges. The frame rotates and contracts before a controlled, terrain-safe collapse.
- **Spatial Deflection** now summons a much larger tesseract overhead, lifts hostiles and incoming projectiles into the field, then banishes captured non-player entities/projectiles and severely damages hostile players at collapse.
- Added a shared cinematic impact helper with a core flash, sonic-boom particle, two colored shockwave rings, and eight radial energy spokes. Omega Beam, Meteor Shower impacts, Gravity Warp, Orbital Strike, Black Hole, Cosmic Nova, Giant Tesseract, and Spatial Deflection use it with distinct colors.
- Expanded ring point quality slightly while retaining the global particle call/particle caps. Hypercube geometry renders every other tick with sparse points so its shape stays legible without turning the whole scene into particle fog.
- The shared impact helper itself is visual-only; damage, projectile behavior, and any existing explosion rules remain controlled by each ability’s gameplay code.
