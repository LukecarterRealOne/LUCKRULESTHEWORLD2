# Forge 1.20.1 build notes

Target: Minecraft Forge 1.20.1 (Forge 47.3.0), Java 17.

This source archive includes fixes for the compiler errors reported by GitHub Actions:
- `Events.java` uses `Abilities#getFlyingSpeed()` and `setFlyingSpeed(float)` instead of accessing the private field.
- `LuckyBlockItem.java` explicitly types the nullable entity argument in `Level#getEntities` to disambiguate the overload.
- `Fx.java` supports both direct `SoundEvent` instances and `Holder<SoundEvent>` values.

Build with `gradle --no-daemon clean build` or use `.github/workflows/build.yml` on GitHub Actions.

A successful ZIP integrity check and source checks are not the same as a successful full Gradle compilation. Run the workflow to confirm the actual compiler result.
